// Background script for X-Plain Chrome Extension

// Create context menu items when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
  // Create a context menu item for direct queries
  chrome.contextMenus.create({
    id: 'directQuery',
    title: 'Explain with Perplexity',
    contexts: ['selection']
  });

  // Create a context menu item for custom questions
  chrome.contextMenus.create({
    id: 'askQuestion',
    title: 'Ask Perplexity a Question',
    contexts: ['selection']
  });
});

// Function to safely send messages to content scripts
function safelySendMessage(tabId, message) {
  // Check if we can inject scripts in this tab
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: () => true,
  })
  .then(() => {
    // If we can execute scripts, try to send the message
    chrome.tabs.sendMessage(tabId, message, (response) => {
      // Check for error
      if (chrome.runtime.lastError) {
        console.log("Content script not ready yet, injecting it now.");
        
        // Inject the content script
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          files: ['content.js']
        })
        .then(() => {
          // Try sending the message again after a short delay
          setTimeout(() => {
            chrome.tabs.sendMessage(tabId, message);
          }, 100);
        })
        .catch(err => console.error("Error injecting content script:", err));
      }
    });
  })
  .catch(err => {
    // If we can't execute scripts in this tab, open a new tab
    console.error("Cannot execute scripts in this tab:", err);
    
    // If it's a direct query or ask question, open Perplexity directly
    if (message.action === 'directQuery') {
      const query = encodeURIComponent(message.text);
      chrome.tabs.create({ url: `https://www.perplexity.ai/?q=${query}` });
    } else if (message.action === 'askQuestion') {
      // For ask question, we'll just open Perplexity in a new tab
      // We can't use chrome.action.openPopup() as it's not available
      alert("Cannot open overlay in this tab. Please use the extension popup or try on a different page.");
      
      // Alternatively, we could open Perplexity with a placeholder
      // const query = encodeURIComponent(`Ask about: "${message.text}"`);
      // chrome.tabs.create({ url: `https://www.perplexity.ai/?q=${query}` });
    }
  });
}

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const selectedText = info.selectionText;
  
  if (!selectedText || !tab.id) {
    return;
  }

  if (info.menuItemId === 'directQuery') {
    // Send message to content script for direct query
    safelySendMessage(tab.id, {
      action: 'directQuery',
      text: selectedText
    });
  } else if (info.menuItemId === 'askQuestion') {
    // Send message to content script to show question overlay
    safelySendMessage(tab.id, {
      action: 'askQuestion',
      text: selectedText
    });
  }
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle any messages from content script or popup
  if (message.action === 'openPerplexity') {
    const query = encodeURIComponent(message.query);
    const url = `https://www.perplexity.ai/?q=${query}`;
    chrome.tabs.create({ url });
  }
  
  return true;
}); 